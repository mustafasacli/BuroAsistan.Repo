namespace BA.UserManagement.Source.QO
{
	/* Query Object Class */
	internal class Crud
	{
	}
}
