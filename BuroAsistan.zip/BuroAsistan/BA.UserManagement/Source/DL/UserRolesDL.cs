using Net.LawORM.Logic.BaseDal;
using System;

namespace BA.UserManagement.Source.DL
{
    internal class UserRolesDL : MainDL
    {
        public UserRolesDL()
            : base()
        {
        }
    }
}
