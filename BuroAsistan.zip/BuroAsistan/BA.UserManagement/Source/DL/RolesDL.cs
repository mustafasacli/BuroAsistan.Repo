using System;
using Net.LawORM.Logic.BaseDal;

namespace BA.UserManagement.Source.DL
{
    internal class RolesDL : MainDL
    {
        public RolesDL()
            : base()
        {
        }
    }
}
