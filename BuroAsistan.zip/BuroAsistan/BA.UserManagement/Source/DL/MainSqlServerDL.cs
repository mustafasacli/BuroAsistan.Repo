﻿using Net.LawORM.Logic.BaseDal;

namespace BA.UserManagement.Source.DL
{
    internal class MainSqlServerDL : BaseDL
    {
        internal MainSqlServerDL()
            : base("buroSQL")
        { }
    }
}