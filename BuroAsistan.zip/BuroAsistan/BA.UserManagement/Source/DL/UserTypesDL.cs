using Net.LawORM.Logic.BaseDal;
using System;

namespace BA.UserManagement.Source.DL
{
    internal class UserTypesDL : MainDL
    {
        public UserTypesDL()
            : base()
        {
        }
    }
}
