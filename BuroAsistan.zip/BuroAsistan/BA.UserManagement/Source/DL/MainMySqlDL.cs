﻿using Net.LawORM.Logic.BaseDal;

namespace BA.UserManagement.Source.DL
{
    internal class MainMySqlDL : BaseDL
    {
        internal MainMySqlDL()
            : base("buroMySQL")
        { }
    }
}