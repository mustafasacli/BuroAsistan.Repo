using System;
using Net.LawORM.Logic.BaseDal;

namespace BA.UserManagement.Source.DL
{
    internal class RoleOperationDL : MainDL
    {
        public RoleOperationDL()
            : base()
        {
        }
    }
}
