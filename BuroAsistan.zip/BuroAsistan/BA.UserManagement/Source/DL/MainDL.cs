﻿namespace BA.UserManagement.Source.DL
{
    internal class MainDL : MainSqlServerDL
    {
        internal MainDL()
            : base()
        { }
    }
}