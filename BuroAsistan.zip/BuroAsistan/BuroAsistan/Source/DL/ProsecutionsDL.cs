using System;
using Net.LawORM.Logic.BaseDal;

namespace BuroAsistan.Source.DL
{
    internal class ProsecutionsDL : MainDL
    {
        internal ProsecutionsDL()
            : base()
        {
        }
    }
}