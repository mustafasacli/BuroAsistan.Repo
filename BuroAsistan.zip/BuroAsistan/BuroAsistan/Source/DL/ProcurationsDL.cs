using System;
using Net.LawORM.Logic.BaseDal;

namespace BuroAsistan.Source.DL
{
    internal class ProcurationsDL : MainDL
    {
        internal ProcurationsDL()
            : base()
        {
        }
    }
}
