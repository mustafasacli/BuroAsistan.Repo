﻿namespace BuroAsistan.Source.DL
{
    internal class MainDL : MainSqlServerDL
    {
        internal MainDL()
            : base()
        { }

    }
}