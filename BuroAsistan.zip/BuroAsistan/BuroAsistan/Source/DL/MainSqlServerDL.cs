﻿using Net.LawORM.Logic.BaseDal;

namespace BuroAsistan.Source.DL
{
    internal class MainSqlServerDL : BaseDL
    {
        internal MainSqlServerDL()
            : base("buroSQL")
        { }
    }
}