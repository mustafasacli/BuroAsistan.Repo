﻿using Net.LawORM.Logic.BaseDal;

namespace BuroAsistan.Source.DL
{
    internal class MainMySqlDL : BaseDL
    {
        internal MainMySqlDL()
            : base("buroMySQL")
        { }
    }
}