using BuroAsistan.Source.BO;
using System;

namespace BuroAsistan.Source.DL
{
    internal class PersonDL : MainDL
    {
        internal PersonDL()
            : base()
        {
        }

    }
}