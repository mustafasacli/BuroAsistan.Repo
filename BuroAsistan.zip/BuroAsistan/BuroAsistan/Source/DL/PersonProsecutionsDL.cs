using System;
using Net.LawORM.Logic.BaseDal;

namespace BuroAsistan.Source.DL
{
    internal class PersonProsecutionsDL : MainDL
	{
		internal PersonProsecutionsDL()
			: base()
		{
		}
	}
}