﻿namespace BuroAsistan.View.BaseView
{
    public class FrmBaseList : FrmBase
    {
        public FrmBaseList()
            : base()
        { }
    }
}
