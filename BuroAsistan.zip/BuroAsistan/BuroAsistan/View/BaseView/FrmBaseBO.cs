﻿namespace BuroAsistan.View.BaseView
{
    public class FrmBaseBO : FrmBase
    {
        protected int _baseBO_Id = -1;

        public FrmBaseBO()
            : base()
        { }
    }
}
